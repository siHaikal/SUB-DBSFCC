import "../style/style.css";
import "./customCard/customCard.js";
import "./customCard/customForm.js";
import "./customCard/customNav.js";
import "./customCard/customLoading";
import main from "./handler";

main();
